public class Test {
    public static void main(String[] args) {
        ApplicationEntreprises entreprise = new ApplicationEntreprises();
        entreprise.run();
    }
}
