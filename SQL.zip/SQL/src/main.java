import java.sql.*;

public class main {
    public static void main(String[] args) throws SQLException {
        String sel = BCrypt.gensalt();

        //amazin pw
        String amazinpwDB = BCrypt.hashpw("amazin123", sel);

        //kookle pw
        String kooklepwDB = BCrypt.hashpw("kookle123", sel);

        //micrasaft pw
        String micrasaftpwDB = BCrypt.hashpw("micrasaft123", sel);

        //pineapple pw
        String pineapplepwDB = BCrypt.hashpw("pineapple123", sel);

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver PostgreSQL manquant !");
            System.exit(1);
        }

        System.out.println("trying to connect to server...");
        String url = "jdbc:postgresql://localhost:5432/dbczhang";
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(url, "postgres", "8861576");
        } catch (SQLException e) {
            System.out.println("Impossible de joindre le serveur !");
            e.printStackTrace();
            System.exit(1);
        }

        //lecture des éléments dans la table projet.entreprises
        Statement st = null;
        ResultSet rs = null;
        try {
            System.out.println("reading elements...");
            st = conn.createStatement();
            rs = st.executeQuery("SELECT * FROM projet.entreprises");
            ResultSetMetaData rsmd = rs.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();

            while (rs.next()) {
                for (int i = 1; i <= numberOfColumns; i++) {
                    String columnName = rsmd.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.println(columnName + ": " + value);
                }
                System.out.println("-------------------");
            }
        } catch (SQLException e) {
            System.out.println("Une erreur s'est produite !");
            e.printStackTrace();
        } finally {
            if (rs != null)
                rs.close();
            if (st != null)
                st.close();
        }


        System.out.println("executing of function crypted_entreprise_pw()...");
        try {
            String functionCall = "SELECT crypted_entreprise_pw(?, ?)";
            PreparedStatement stmt = conn.prepareStatement(functionCall);

            stmt.setString(1, kooklepwDB);
            stmt.setInt(2, 1);
            stmt.execute();

            stmt.setString(1, micrasaftpwDB);
            stmt.setInt(2, 2);
            stmt.execute();

            stmt.setString(1, pineapplepwDB);
            stmt.setInt(2, 3);
            stmt.execute();

            stmt.close();
            System.out.println("executed successfully");
        } catch (SQLException se) {
            System.out.println("Erreur lors de l’insertion !");
            se.printStackTrace();
            System.exit(1);
        }

        System.out.println("checking password...");
        if(BCrypt.checkpw("kookle123", kooklepwDB))
            System.out.println("password correct");
        else
            System.out.println("wrong password");
        if(BCrypt.checkpw("micrasaft123", micrasaftpwDB))
            System.out.println("password correct");
        else
            System.out.println("wrong password");
        if(BCrypt.checkpw("pineapple123", pineapplepwDB))
            System.out.println("password correct");
        else
            System.out.println("wrong password");
        System.out.println("all password verified");

    }
}