import org.w3c.dom.ls.LSOutput;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.Scanner;


public class Etudiant {
    public void run() {
        Professeur pourLeSel = new Professeur();
        int choix;
        Scanner scanner = new Scanner(System.in);
        String url = "jdbc:postgresql://172.24.2.6:5432/dbchuqizhang";
        Connection conn = null;
        PreparedStatement ps;

        try {
            conn = DriverManager.getConnection(url, "monanaitmazi", "BTU7IECD6");
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }


        int id_etudiant_connecte = -1;
        boolean is_etudiant;
        String mailEtudiant, motDePasseEtudiant;

        System.out.println("Authentifiez-vous s'il-vous-plait");
        System.out.println("Entrez votre adresse mail : ");
        mailEtudiant = scanner.nextLine();
        System.out.println("Entrez votre mot de passe : ");
        motDePasseEtudiant = scanner.nextLine();

        try {
            System.out.println("authentification...");

            String functionCall = "SELECT et.mot_de_passe, et.id_etudiant FROM projet.etudiants et WHERE et.adresse_mail = ?";
            PreparedStatement stmt = conn.prepareStatement(functionCall);
            stmt.setString(1, mailEtudiant);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                is_etudiant = BCrypt.checkpw(motDePasseEtudiant, rs.getString("mot_de_passe"));
                if(is_etudiant)
                    id_etudiant_connecte = rs.getInt("id_etudiant");
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors d'authentification ! ");
            e.printStackTrace();
        }



        if (id_etudiant_connecte != -1) {
            System.out.println("---MENU---");
            System.out.println("1. Voir toutes les offres de stage validées");
            System.out.println("2. Rechercher une offre par mot clé");
            System.out.println("3. Poser votre candidature");
            System.out.println("4. Voir les offres pour lesquelles vous avez postulé");
            System.out.println("5. Annuler une de vos candidatures");
            System.out.println("6. Quitter");

            do {
                System.out.println("Entrez votre choix : ");
                choix = scanner.nextInt();
                scanner.nextLine();

                switch (choix) {
                    case 1:
                        String resultat = "";
                        String quadri2;
                        System.out.println("A quel quadri faites-vous votre stage ?");
                        quadri2 = scanner.nextLine();
                        try {
                            ps = conn.prepareStatement("SELECT * FROM offres_par_mot_cles WHERE semestre = ?;");
                            ps.setString(1, quadri2);
                            ResultSet rs = ps.executeQuery();
                            while (rs.next()) {
                                resultat += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        } catch (SQLException se) {
                            System.out.println("Erreur lors de l’insertion !");
                            se.printStackTrace();
                            System.exit(1);
                        }
                        System.out.println(resultat);
                        break;

                    case 2:
                        String motCle, quadri;
                        String resultat2 = "";
                        System.out.println("Entrez le mot clé pour lequel vous voulez voir les offres : ");
                        motCle = scanner.nextLine();
                        System.out.println("Faites-vous un stage au q1 ou au q2 ?");
                        quadri = scanner.nextLine();
                        try {
                            ps = conn.prepareStatement("SELECT * FROM offres_par_mot_cles WHERE semestre = ? AND intitule = ?;");
                            ps.setString(1, quadri);
                            ps.setString(2, motCle);

                            ResultSet rs = ps.executeQuery();
                            while (rs.next()) {
                                resultat2 += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        } catch (SQLException se) {
                            System.out.println("Erreur lors de l’insertion !");
                            se.printStackTrace();
                            System.exit(1);
                        }
                        System.out.println(resultat2);
                        break;

                    case 3:
                        String offre, motivation;
                        System.out.println("Entrez le code de l'offre pour laquelle vous désirez postuler : ");
                        offre = scanner.nextLine();
                        System.out.println("Entrez une brève description de vos motivations : ");
                        motivation = scanner.nextLine();
                        try {
                            ps = conn.prepareStatement("SELECT poser_candidature(?, ?, ?)");
                            ps.setString(1, offre);
                            ps.setString(2, motivation);
                            ps.setInt(3, id_etudiant_connecte);
                            ps.execute();
                        } catch (SQLException se) {
                            System.out.println("Erreur lors de l’insertion !");
                            se.printStackTrace();
                            System.exit(1);
                        }
                        break;

                    case 4:
                        String resultat3 = "";
                        try {
                            ps = conn.prepareStatement("SELECT * FROM offres_avec_candidature WHERE etudiant = ?;");
                            ps.setInt(1, id_etudiant_connecte);
                            ResultSet rs = ps.executeQuery();
                            while (rs.next()) {
                                resultat3 += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        } catch (SQLException se) {
                            System.out.println("Erreur lors de l’insertion !");
                            se.printStackTrace();
                            System.exit(1);
                        }
                        System.out.println(resultat3);
                        break;

                    case 5:
                        String offreAnnulee;
                        System.out.println("Entrez le code de l'offre pour laquelle vous voulez retirer votre candidature : ");
                        offreAnnulee = scanner.nextLine();
                        try {
                            ps = conn.prepareStatement("SELECT annuler_candidature(?, ?)");
                            ps.setString(1, offreAnnulee);
                            ps.setInt(2, id_etudiant_connecte);
                            ps.execute();
                        } catch (SQLException se) {
                            System.out.println("Erreur lors de l’insertion !");
                            se.printStackTrace();
                            System.exit(1);
                        }
                        break;
                }
            } while (choix != 6);
        } else {
            System.out.println("FRAUDE !!!!!!");
        }
    }
}

