public class TestProf {
    public static void main(String[] args) {
        Professeur prof = new Professeur();
        prof.run();
    }
}
