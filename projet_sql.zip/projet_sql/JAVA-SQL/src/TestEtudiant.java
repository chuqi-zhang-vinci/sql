public class TestEtudiant {
    public static void main(String[] args) {
        Etudiant etudiant = new Etudiant();
        etudiant.run();
    }
}
