import java.sql.*;
import java.util.Scanner;

public class Professeur{
    public void run(){
        int choix;
        Scanner scanner = new Scanner(System.in);
        String url = "jdbc:postgresql://172.24.2.6:5432/dbchuqizhang";
        Connection conn = null;
        PreparedStatement ps;

        try{
            conn = DriverManager.getConnection(url, "monanaitmazi", "BTU7IECD6");
        }catch(SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }

        System.out.println("---MENU---");
        System.out.println("1. Encoder un étudiant");
        System.out.println("2. Encoder une entreprise");
        System.out.println("3. Encoder un mot-clé");
        System.out.println("4. Voir les offres de stage non-validées");
        System.out.println("5. Valider une offre de stage");
        System.out.println("6. Voir les offres de stage validées");
        System.out.println("7. Voir les étudiants qui n'ont pas de stage");
        System.out.println("8. Voir les offres de stage attribuées");
        System.out.println("9. Quitter");

        do{
            System.out.println("Entrez votre choix : ");
            choix = scanner.nextInt();
            scanner.nextLine();

            switch(choix){
                case 1 :
                    String nom, prenom, mail, semestre, mdp;
                    System.out.println("Entrez le nom de l'étudiant à encoder : ");
                    nom = scanner.nextLine();
                    System.out.println("Entrez son prénom : ");
                    prenom = scanner.nextLine();
                    System.out.println("Son adresse mail : ");
                    mail = scanner.nextLine();
                    System.out.println("Fait-il son stage au q1 ou au q2 ? ");
                    semestre = scanner.nextLine();
                    System.out.println("Entrez son mot de passe : ");
                    mdp = scanner.nextLine();
                    String selEtudiant = BCrypt.gensalt();
                    String mdpCrypted = BCrypt.hashpw(mdp, selEtudiant);
                    try {
                        ps = conn.prepareStatement("SELECT projet.encoder_etudiant(?, ?, ?, ?, ?)");
                        ps.setString(1, nom);
                        ps.setString(2, prenom);
                        ps.setString(3, mail);
                        ps.setString(4, semestre);
                        ps.setString(5, mdpCrypted);
                        ps.execute();
                    } catch (SQLException se) {
                        System.out.println("Erreur lors de l’insertion !");
                        se.printStackTrace();
                        System.exit(1);
                    }
                    break;

                case 2 :
                    String nom2, adresse, mail2, identifiant, mdp2;
                    System.out.println("Entrez le nom de l'entreprise que vous désirez ajouter : ");
                    nom2 = scanner.nextLine();
                    System.out.println("Entrez son adresse : ");
                    adresse = scanner.nextLine();
                    System.out.println("Entrez son adresse mail : ");
                    mail2 = scanner.nextLine();
                    System.out.println("Donnez-lui un identifiant (3 lettres majuscules) : ");
                    identifiant = scanner.nextLine();
                    System.out.println("Donnez-lui un mot de passe : ");
                    mdp2 = scanner.nextLine();
                    String selEntreprise = BCrypt.gensalt();
                    String mdpCrypted2 = BCrypt.hashpw(mdp2, selEntreprise);
                    try {
                        ps = conn.prepareStatement("SELECT encoder_entreprises(?, ?, ?, ?, ?);");
                        ps.setString(1, nom2);
                        ps.setString(2, adresse);
                        ps.setString(3, mail2);
                        ps.setString(4, identifiant);
                        ps.setString(5, mdpCrypted2);
                        ps.execute();
                    } catch (SQLException se) {
                        System.out.println("Erreur lors de l’insertion !");
                        se.printStackTrace();
                        System.exit(1);
                    }
                    break;

                case 3 :
                    String motCle;
                    System.out.println("Quel est le mot clé à encoder ? ");
                    motCle = scanner.nextLine();
                    try {
                        ps = conn.prepareStatement("SELECT encoder_mot_cle(?);");
                        ps.setString(1, motCle);
                        ps.execute();
                    } catch (SQLException se) {
                        System.out.println("Erreur lors de l’insertion !");
                        se.printStackTrace();
                        System.exit(1);
                    }
                    break;

                case 4 :
                    String resultat = "";
                    try {
                        Statement s = conn.createStatement();
                        try(ResultSet rs= s.executeQuery("SELECT * FROM offres_non_validees;")){
                            while(rs.next()) {
                                resultat += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                            + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        }
                    } catch (SQLException se) {
                        se.printStackTrace();
                        System.exit(1);
                    }
                    System.out.println(resultat);
                    break;

                case 5 :
                    String code;
                    System.out.println("Entrez le code de l'offre que vous voulez valider : ");
                    code = scanner.nextLine();
                    try {
                        ps = conn.prepareStatement("SELECT valider_offre(?);");
                        ps.setString(1, code);
                        ps.execute();
                    } catch (SQLException se) {
                        System.out.println("Erreur lors de l’insertion !");
                        se.printStackTrace();
                        System.exit(1);
                    }
                    break;

                case 6 :
                    String resultat2 = "";
                    try {
                        Statement s = conn.createStatement();
                        try(ResultSet rs= s.executeQuery("SELECT * FROM offres_validees;")){
                            while(rs.next()) {
                                resultat2 += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        }
                    } catch (SQLException se) {
                        se.printStackTrace();
                        System.exit(1);
                    }
                    System.out.println(resultat2);
                    break;

                case 7 :
                    String resultat3 = "";
                    try {
                        Statement s = conn.createStatement();
                        try(ResultSet rs= s.executeQuery("SELECT * FROM etudiants_sans_stage;")){
                            while(rs.next()) {
                                resultat3 += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\t" +
                                        rs.getString(5) + "\n";
                            }
                        }
                    } catch (SQLException se) {
                        se.printStackTrace();
                        System.exit(1);
                    }
                    System.out.println(resultat3);
                    break;

                case 8 :
                    String resultat4 = "";
                    try {
                        Statement s = conn.createStatement();
                        try(ResultSet rs= s.executeQuery("SELECT * FROM offres_attribuees;")){
                            while(rs.next()) {
                                resultat4 += rs.getString(1) + "\t" + rs.getString(2) + "\t"
                                        + rs.getString(3) + "\t" + rs.getString(4) + "\n";
                            }
                        }
                    } catch (SQLException se) {
                        se.printStackTrace();
                        System.exit(1);
                    }
                    System.out.println(resultat4);
                    break;
            }
        }while(choix != 9);
    }
}
